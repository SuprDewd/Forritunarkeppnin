﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using GameLibrary;
using SharpBag;
using SharpBag.Logging;
using SharpBag.Networking;
using SharpBag.Strings;

namespace GameServer
{
    public class GameServer
    {
        private static void Main(string[] args)
        {
            new GameServer().Run();
        }

        public Host Server { get; private set; }

        public int Port { get; private set; }

        private Logger Log { get; set; }

        private InteractiveConsole ConsoleManager { get; set; }

        public BilaHnuturNetworking Board { get; private set; }

        public List<Board> Boards = new List<Board>();

        public void LoadBoards()
        {
            Boards.Clear();
            string[] txtBS = File.ReadAllText("Levels.txt").Split(new string[] { Environment.NewLine + Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < txtBS.Length; i++)
            {
                string[] curLines = txtBS[i].Lines();
                int[,] board = new int[curLines.Length, curLines[0].Split(',').Length];

                for (int l = 0; l < curLines.Length; l++)
                {
                    int[] blar = curLines[l].Split(',').Select(b => b.As<int>()).ToArray();
                    for (int c = 0; c < blar.Length; c++)
                    {
                        board[c, l] = blar[c];
                    }
                }

                Boards.Add(new Board { ExitX = 2, ExitY = 5, TheBoard = board });
            }

            Boards = Boards.Shuffle().ToList();
        }

        public void Run()
        {
            this.ConsoleManager = new InteractiveConsole();
            this.Log = new Logger(s => { if (this.ConsoleManager != null) this.ConsoleManager.WriteLine(s); else Console.WriteLine(s); });
            this.Port = 1337.To(0xFFFF).First(Network.IsPortFree);
            Network.LocalIPAddresses.Where(ip => ip.AddressFamily == AddressFamily.InterNetwork).ForEach(ip => this.Log.Log("IP:\t" + ip.ToString()));
            this.Log.Log("Port:\t" + this.Port + "\n");
            this.Server = new Host(this.Port);
            this.Board = new BilaHnuturNetworking();
            this.LoadBoards();
            this.Board.LoadBoard(Boards[0]);
            this.Boards.RemoveAt(0);

            /*for (int x = 0; x < this.Board.CurrentBoard.Board.GetLength(0); x++)
            {
                for (int y = 0; y < this.Board.CurrentBoard.Board.GetLength(1); y++)
                {
                    Console.Write(this.Board.CurrentBoard.Board[x, y]);
                }

                Console.WriteLine();
            }

            Console.ReadLine();*/

            this.Board.GameOver += () =>
                {
                    if (this.Boards.Count == 0) this.LoadBoards();
                    this.Board.LoadBoard(Boards[0]);
                    this.Boards.RemoveAt(0);
                };

            try
            {
                this.Server.Open();

                this.Server.OnClientConnected += client =>
                    {
                        this.Log.Log("Connected: " + client.RemoteEndPoint.ToString());
                        client.OnDisconnect += () => { this.Log.Log("Disconnected: " + client.RemoteEndPoint.ToString()); };
                        client.Subscribe<Move>((int)Actions.TryMove, (m, ea) =>
                            {
                                bool moved = this.Board.Move(m);

                                if (moved)
                                {
                                    this.Server.Fire((int)Actions.RefreshBoard, new Board
                                    {
                                        TheBoard = this.Board.CurrentBoard.Board,
                                        ExitX = this.Board.ExitX,
                                        ExitY = this.Board.ExitY
                                    });
                                }
                            });

                        client.Subscribe((int)Actions.NeedRefresh, (o, ea) =>
                            {
                                client.Fire((int)Actions.RefreshBoard, new Board
                                {
                                    TheBoard = this.Board.CurrentBoard.Board,
                                    ExitX = this.Board.ExitX,
                                    ExitY = this.Board.ExitY
                                });
                            });
                    };

                bool exit = false;
                while (!exit)
                {
                    string cmd = this.ConsoleManager.ReadCommand();

                    switch (cmd.Split(' ')[0].ToUpper())
                    {
                        case "EXIT":
                        case "QUIT":
                        case "DIE":
                        case "STOP":
                        case "CLOSE": exit = true; break;
                    }
                }
            }
            catch (Exception e)
            {
                this.Log.Log(e.Message);
                this.Log.Log(e.StackTrace);
                // throw e;
            }
            finally
            {
                try
                {
                    this.Server.Dispose();
                }
                catch { this.Log.Log("Failed to dispose server."); }
            }

            this.ConsoleManager.CommandStart = "";
            this.Log.Log("Server closed.");
            this.ConsoleManager.ReadCommand();

            try
            {
                this.ConsoleManager.Stop();
            }
            catch { }
            Environment.Exit(0);
        }
    }
}