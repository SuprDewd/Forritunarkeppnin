﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpBag;
using SharpBag.Math;
using SharpBag.Strings;

namespace GameLibrary
{
    public class BilaHnutur
    {
        public int Width { get; private set; }

        public int Height { get; private set; }

        public int[,] Board { get; private set; }

        public Random RandGen { get; private set; }

        public BilaHnutur(int width, int height)
        {
            this.Width = width;
            this.Height = height;
            this.Board = new int[height, width];
            this.RandGen = new Random();
        }

        public void Clear()
        {
            for (int x = 0; x < this.Height; x++)
            {
                for (int y = 0; y < this.Width; y++)
                {
                    this.Board[x, y] = 0;
                }
            }
        }

        public bool PutCar(int num, int len, int x, int y, int xDelta, int yDelta)
        {
            var line = this.Board.Line(x, y, xDelta, yDelta).Take(len);
            if (line.Count() < len || line.Any(i => i != 0)) return false;

            for (int curLen = 0; curLen < len; curLen++)
            {
                this.Board[x, y] = num;
                x += xDelta;
                y += yDelta;
            }

            return true;
        }

        public void TakeCar(int len, int x, int y, int xDelta, int yDelta)
        {
            for (int curLen = 0; curLen < len; curLen++)
            {
                this.Board[x, y] = 0;
                x += xDelta;
                y += yDelta;
            }
        }

        public bool AddOne(int[] cars, int cur)
        {
            if (cur == cars.Length + 2) return true;
            int carLen = cars[cur - 2];

            for (int num = 0; num < 100000; num++)
            {
                int x = RandGen.Next(0, this.Height);
                int y = RandGen.Next(0, this.Height);

                for (int xDelta = -1; xDelta <= 1; xDelta++)
                {
                    for (int yDelta = -1; yDelta <= 1; yDelta++)
                    {
                        if (((yDelta == 0 || xDelta == 0) && xDelta != yDelta) && PutCar(cur, carLen, x, y, xDelta, yDelta))
                        {
                            if (AddOne(cars, cur + 1)) return true;
                            else TakeCar(carLen, x, y, xDelta, yDelta);
                        }
                    }
                }
            }

            return false;
        }

        public bool Randomize(int[] cars, Tuple<int, int> exitXY1, Tuple<int, int> exitXY2, int moveTimes)
        {
            cars = cars.Shuffle().ToArray();
            bool done = false;
            for (int num = 0; num < 100000; num++)
            {
                this.Clear();
                this.Board[exitXY1.Item1, exitXY1.Item2] = 1;
                this.Board[exitXY2.Item1, exitXY2.Item2] = 1;
                if (AddOne(cars, 2))
                {
                    done = true;
                    break;
                }
            }

            if (!done) return false;
            MoveCarsLikeCrazy(moveTimes);
            // return true;
            var q = this.Board.Line(exitXY1.Item1, exitXY1.Item2, exitXY2.Item1 - exitXY1.Item1, exitXY2.Item2 - exitXY1.Item2).TakeWhile(i => i != 1).ToArray();
            return q.Length > 0 && q.Any(i => i != 0); //this.Board[exitXY1.Item1, exitXY1.Item2] != 1 && this.Board[exitXY2.Item1, exitXY2.Item2] != 1;
        }

        private void MoveCarsLikeCrazy(int moveTimes)
        {
            for (int i = 0; i < moveTimes; i++)
            {
                Tuple<int, int>[] car = GetRandomCar();
                MoveCarRandom(car);
            }
        }

        private void MoveCarRandom(Tuple<int, int>[] car)
        {
            bool dirFirst = this.RandGen.NextBool();
            int xDelta = car[1].Item1 - car[0].Item1;
            int yDelta = car[1].Item2 - car[0].Item2;
            int carNum = this.Board[car[0].Item1, car[0].Item2];

            Func<int, bool> doStuff = dir =>
                {
                    if (dir == 0 || (carNum == 1 && dir == 1)) return false;
                    xDelta *= dir;
                    yDelta *= dir;

                    int fX = car[0].Item1 + xDelta, fY = car[0].Item2 + yDelta;

                    if (fX < 0 || fY < 0 || fX >= this.Height || fY >= this.Width || this.Board[fX, fY] != 0) return false;

                    for (int i = 0; i < car.Length; i++)
                    {
                        this.Board[car[i].Item1 + xDelta, car[i].Item2 + yDelta] = carNum;
                        this.Board[car[i].Item1, car[i].Item2] = 0;
                    }

                    return true;
                };

            if (dirFirst)
            {
                for (int dir = -1; dir <= 1; dir++)
                {
                    if (doStuff(dir)) break;
                }
            }
            else
            {
                for (int dir = 1; dir >= -1; dir--)
                {
                    if (doStuff(dir)) break;
                }
            }
        }

        public Tuple<int, int>[] GetCarAt(int x, int y)
        {
            if (x < 0 || y < 0 || x > this.Board.GetLength(0) || y > this.Board.GetLength(1)) return null;
            int n = this.Board[x, y];
            if (n == 0) return null;
            return this.Board.AsEnumerable().Where(c => c.Item3 == n).Select(c => new Tuple<int, int>(c.Item1, c.Item2)).OrderBy(c => c.Item1).ThenBy(c => c.Item2).ToArray();
        }

        private Tuple<int, int>[] GetRandomCar()
        {
            while (true)
            {
                int x = this.RandGen.Next(0, this.Height),
                y = this.RandGen.Next(0, this.Width),
                n = this.Board[x, y];
                if (n == 0) continue;
                return this.Board.AsEnumerable().Where(c => c.Item3 == n).Select(c => new Tuple<int, int>(c.Item1, c.Item2)).OrderBy(c => c.Item1).ThenBy(c => c.Item2).ToArray();
            }
        }
    }
}