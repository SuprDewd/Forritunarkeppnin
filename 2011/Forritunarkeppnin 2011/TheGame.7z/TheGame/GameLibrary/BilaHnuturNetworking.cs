﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameLibrary
{
    public class BilaHnuturNetworking
    {
        public BilaHnutur CurrentBoard { get; set; }

        public event Action GameOver;

        public int ExitX { get; set; }

        public int ExitY { get; set; }

        public BilaHnuturNetworking()
        {
        }

        public bool Move(Move m)
        {
            try
            {
                int num;
                if (m.Fra.X == m.Til.X && m.Fra.Y == m.Til.Y) return false;
                if ((num = this.CurrentBoard.Board[m.Fra.X, m.Fra.Y]) == 0) return false;
                if (!(m.Fra.X == m.Til.X || m.Fra.Y == m.Til.Y)) return false;
                Tuple<int, int>[] car = this.CurrentBoard.GetCarAt(m.Fra.X, m.Fra.Y);
                if (car == null) return false;

                int xDelta = m.Til.X - m.Fra.X;
                int yDelta = m.Til.Y - m.Fra.Y;
                int cxDelta = car[1].Item1 - car[0].Item1;
                int cyDelta = car[1].Item2 - car[0].Item2;

                if (cxDelta == 0 && xDelta != 0) return false;
                if (cyDelta == 0 && yDelta != 0) return false;

                if (xDelta > 0) xDelta = 1;
                if (xDelta < 0) xDelta = -1;
                if (yDelta > 0) yDelta = 1;
                if (yDelta < 0) yDelta = -1;

                if (xDelta > 0 || yDelta > 0)
                {
                    if (this.CurrentBoard.Board[car.Last().Item1 + xDelta, car.Last().Item2 + yDelta] != 0) return false;

                    for (int i = car.Length - 1; i >= 0; i--)
                    {
                        this.CurrentBoard.Board[car[i].Item1 + xDelta, car[i].Item2 + yDelta] = num;
                        this.CurrentBoard.Board[car[i].Item1, car[i].Item2] = 0;
                    }
                }
                else
                {
                    if (this.CurrentBoard.Board[car[0].Item1 + xDelta, car[0].Item2 + yDelta] != 0) return false;

                    for (int i = 0; i < car.Length; i++)
                    {
                        this.CurrentBoard.Board[car[i].Item1 + xDelta, car[i].Item2 + yDelta] = num;
                        this.CurrentBoard.Board[car[i].Item1, car[i].Item2] = 0;
                    }
                }

                if (this.CurrentBoard.Board[this.ExitX, this.ExitY] == 1)
                {
                    this.GameOver();
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public void LoadBoard(Board board)
        {
            if (this.CurrentBoard == null) this.CurrentBoard = new BilaHnutur(board.TheBoard.GetLength(0), board.TheBoard.GetLength(1));
            this.CurrentBoard.Clear();

            for (int x = 0; x < board.TheBoard.GetLength(0); x++)
            {
                for (int y = 0; y < board.TheBoard.GetLength(1); y++)
                {
                    this.CurrentBoard.Board[y, x] = board.TheBoard[x, y];
                }
            }

            this.ExitX = board.ExitX;
            this.ExitY = board.ExitY;
        }
    }
}