﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GameTemplate
{
    /// <summary>
    /// Interaction logic for Popup.xaml
    /// </summary>
    public partial class Popup : Window
    {
        public Popup(string title, string desc, Dictionary<string, Action> buttons)
        {
            InitializeComponent();
            this.Title = title;
            this.Desc.Text = desc;

            foreach (KeyValuePair<string, Action> item in buttons)
            {
                Button b = new Button
                {
                    Content = item.Key
                };

                Action a = item.Value;
                b.Click += (o, ea) => { a(); this.Close(); };
                b.Style = (Style)this.Resources["Btn"];

                this.Buttons.Children.Add(b);
            }
        }
    }
}
