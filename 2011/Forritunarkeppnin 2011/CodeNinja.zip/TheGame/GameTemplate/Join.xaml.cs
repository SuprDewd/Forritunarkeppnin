﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using GameLibrary;
using SharpBag;
using SharpBag.Networking;

namespace GameTemplate
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Join : Window
    {
        public Join()
        {
            // new Game().ShowDialog();
            // Environment.Exit(0);

            InitializeComponent();
            this.Title = this.lblName.Text = Properties.Settings.Default.GameName;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.txtIP.Focus();
        }

        public Client Client { get; private set; }

        private void ToggleStuff(bool play)
        {
            this.JoinHost.IsEnabled = play;
            this.Waiting.IsEnabled = !play;
            this.btnPlay.Content = play ? "Play" : "Waiting";

            this.txtIP.Focus();
        }

        private void SwitchView(bool play)
        {
            this.JoinHost.Height = play ? 245 : 0;
        }

        private void StopWaiting(object sender, RoutedEventArgs e)
        {
            this.Client.OnDisconnected -= Client_OnDisconnected;
            if (this.Client != null) { this.Client.Dispose(); this.Client = null; }
            this.ToggleStuff(true);
            this.SwitchView(true);
        }

        private void Play(object sender, RoutedEventArgs e)
        {
            this.ToggleStuff(false);

            try
            {
                this.Client = new Client(this.txtIP.Text, Convert.ToInt32(this.txtPort.Text));
                this.Client.OnDisconnected += Client_OnDisconnected;

                /*this.Client.Subscribe((int)Actions.YouAre, (o, ea) =>
                    {
                        this.InvokeIfRequired(() =>
                            {
                                Game g = new Game(this.Client);
                                this.Close();
                                g.ShowDialog();
                                this.Show();
                            });
                    });*/

                this.Client.Open();

                this.Hide();
                new Game(this.Client)
                {
                    WindowState = System.Windows.WindowState.Maximized
                }.ShowDialog();
                this.Show();
                this.ToggleStuff(true);

                // this.Client.Subscribe(StartGame, (o, ea) => new Game().Show(this.Client))

                // this.SwitchView(false);
            }
            catch
            {
                bool retry = false;
                new Popup("Error", "The server could not be reached.", new Dictionary<string, Action> { { "OK", () => { } }, { "Retry", () =>
                                                                                                                             {
                                                                                                                                 retry = true;
                                                                                                                             }} }).ShowDialog();
                this.ToggleStuff(true);

                if (retry)
                {
                    StopWaiting(null, null);
                    Play(null, null);
                }
            }
        }

        private void Client_OnDisconnected()
        {
            this.InvokeIfRequired(() =>
            {
                new Popup("Error", "Connection to server lost.", new Dictionary<string, Action> { { "OK", () => { } } }).ShowDialog();
                this.StopWaiting(null, null);
            });
        }

        private void TextBoxGotFocus(object sender, RoutedEventArgs e)
        {
            TextBox txt = sender as TextBox;
            txt.SelectAll();
        }
    }
}