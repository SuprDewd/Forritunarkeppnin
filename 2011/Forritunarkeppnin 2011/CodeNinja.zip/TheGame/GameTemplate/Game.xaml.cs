﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using GameLibrary;
using GameTemplate.Properties;
using SharpBag;
using SharpBag.Networking;

namespace GameTemplate
{
    /// <summary>
    /// Interaction logic for Game.xaml
    /// </summary>
    public partial class Game : Window
    {
        public Client Client { get; set; }

        public BilaHnuturNetworking BH { get; set; }

        public Game(Client c)
        {
            /*foreach (Color color in Enum.GetValues(typeof()))
            {
                if (color == Colors.Red || color == Colors.White) continue;
                this.CarColors.Add(color);
            }*/

            // this.CarColors = this.CarColors.Shuffle().ToList();

            this.KeyUp += (o, ea) =>
                {
                    if (this.CurX == null || this.CurY == null) return;
                    int xDelta = ea.Key == Key.Up ? -1 : ea.Key == Key.Down ? 1 : 0;
                    int yDelta = ea.Key == Key.Left ? -1 : ea.Key == Key.Right ? 1 : 0;

                    if (xDelta != 0 | yDelta != 0) this.Client.Fire<Move>((int)Actions.TryMove, new Move
                        {
                            Fra = new Hnit { X = this.CurX.Value, Y = this.CurY.Value },
                            Til = new Hnit { X = this.CurX.Value + xDelta, Y = this.CurY.Value + yDelta }
                        });
                };

            this.Client = c;
            this.Client.Subscribe<Board>((int)Actions.RefreshBoard, (b, ea) =>
                {
                    if (this.LastCar != 0)
                    {
                        for (int x = 0; x < b.TheBoard.GetLength(0); x++)
                        {
                            for (int y = 0; y < b.TheBoard.GetLength(1); y++)
                            {
                                if (b.TheBoard[x, y] == this.LastCar)
                                {
                                    this.CurX = x;
                                    this.CurY = y;
                                    goto done;
                                }
                            }
                        }
                    }

                done:
                    this.InvokeIfRequired(() => DrawBoard(b));
                });
            InitializeComponent();

            this.Width = Settings.Default.GameWidth + 60;
            this.Height = Settings.Default.GameHeight + 70;

            this.CreateBoard(6, 6, Settings.Default.GameWidth, Settings.Default.GameHeight, this.Board, this.OuterBorder, this.brdContent);
            this.Client.Fire((int)Actions.NeedRefresh);
        }

        Random r = new Random();
        Border[,] Borders = new Border[6, 6];
        List<Color> CarColors = new List<Color>()
        {
            Colors.White,
            Colors.Red,
            Colors.Blue,
            Colors.Green,
            Colors.Orange,
            Colors.MediumVioletRed,
            Colors.Firebrick,
            Colors.Maroon,
            Colors.DarkGray,
            Colors.Aquamarine,
            Colors.Khaki,
            Colors.IndianRed,
            Colors.Fuchsia,
            Colors.Goldenrod,
            Colors.Lavender
        };

        public int? LastCar = null;
        public int? CurX = null;
        public int? CurY = null;

        public void DrawBoard(Board b)
        {
            for (int x = 0; x < 6; x++)
            {
                for (int y = 0; y < 6; y++)
                {
                    int n = b.TheBoard[x, y], curX = x, curY = y;
                    Borders[y, x].Background = new SolidColorBrush(this.CarColors[n] /*n.Match<int, Color>().When(0, Colors.White).When(1, Colors.Red).Default(this.CarColors.Random()).EndMatch()*/);
                    Borders[y, x].MouseDown += (o, ea) =>
                        {
                            CurX = curX;
                            CurY = curY;
                            LastCar = n;
                        };
                }
            }
        }

        public void CreateBoard(int rows, int cols, int width, int height, Grid board, Border outerBorder, Border innerBorder)
        {
            board.Children.Clear();
            board.ColumnDefinitions.Clear();
            board.RowDefinitions.Clear();
            board.Margin = new Thickness(10);
            outerBorder.Width = width + 20;
            outerBorder.Height = height + 20;
            innerBorder.Width = width;
            innerBorder.Height = height;
            for (int x = 0; x < cols; x++) board.ColumnDefinitions.Add(new ColumnDefinition());
            for (int y = 0; y < rows; y++) board.RowDefinitions.Add(new RowDefinition());

            bool startLight = true;
            for (int y = 0; y < rows; y++)
            {
                bool light = startLight;

                for (int x = 0; x < cols; x++)
                {
                    int nX = x, nY = y;
                    Border border = new Border();
                    border.Background = new SolidColorBrush(light ? Color.FromRgb(0xFF, 0xCE, 0x9E) : Color.FromRgb(0xD1, 0x8B, 0x47));
                    Grid.SetColumn(border, nX);
                    Grid.SetRow(border, nY);
                    this.Borders[nX, nY] = border;
                    board.Children.Add(border);
                    light = !light;
                }

                startLight = !startLight;
            }
        }
    }
}