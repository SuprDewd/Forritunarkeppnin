﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameLibrary
{
    [Serializable]
    public class Board
    {
        public int[,] TheBoard { get; set; }

        public int ExitX { get; set; }

        public int ExitY { get; set; }
    }
}