﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameLibrary
{
    public static class Extensions
    {
        public static IEnumerable<Tuple<int, int, T>> AsEnumerable<T>(this T[,] board)
        {
            for (int x = 0; x < board.GetLength(0); x++)
            {
                for (int y = 0; y < board.GetLength(1); y++)
                {
                    yield return new Tuple<int, int, T>(x, y, board[x, y]);
                }
            }
        }
    }
}