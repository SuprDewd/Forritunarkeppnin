﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameLibrary
{
    [Serializable]
    public class Hnit
    {
        public int X;
        public int Y;
    }
}